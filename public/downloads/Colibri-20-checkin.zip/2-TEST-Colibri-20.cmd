@echo off
title Colibri 20 - test check-in
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0colibri-checkin.ps1" -Test -Unit "Colibri 20" -Role "Control cabinet"
echo.
pause
