@echo off
title Colibri 20 - install check-in
rem Re-open as administrator if needed
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Asking for administrator permission...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -Path '%~dp0colibri-checkin.ps1'" >nul 2>&1
echo.
echo Installing the Colibri check-in for: Colibri 20 (Control cabinet)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0colibri-checkin.ps1" -Install -Unit "Colibri 20" -Role "Control cabinet"
echo.
echo Open the status page to confirm Colibri 20 shows Online:
echo https://tangerine-smakager-bdebcf.netlify.app/colibri-status.html
echo.
pause
