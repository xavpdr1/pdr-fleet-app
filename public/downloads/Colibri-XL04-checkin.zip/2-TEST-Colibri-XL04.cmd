@echo off
title Colibri XL04 - test check-in
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0colibri-checkin.ps1" -Test -Unit "Colibri XL04" -Role "Control cabinet"
echo.
pause
