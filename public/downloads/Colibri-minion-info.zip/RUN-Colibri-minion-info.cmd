@echo off
title Colibri minion info (read only)
cd /d "%~dp0"
echo Collecting minion info. This takes about a minute and changes nothing...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0colibri-minion-info.ps1"
echo.
pause
