<#
  Colibri minion info (PDR-Team) - READ ONLY.
  Collects what's needed to count minions on the status page:
  network connections to Colibri Core, minion addresses, and where Colibri Core keeps its logs.
  It does not change anything on this PC and sends nothing over the internet.
  The result is saved as a text file next to this script.
#>
$ErrorActionPreference = "Continue"
$out = Join-Path $PSScriptRoot ("minion-info-{0}-{1}.txt" -f $env:COMPUTERNAME, (Get-Date -Format "yyyyMMdd-HHmm"))
function Sec($t) { "`r`n==================== $t ====================" | Out-File $out -Append -Encoding UTF8 }
function Put($x) { ($x | Out-String -Width 250) | Out-File $out -Append -Encoding UTF8 }

"Colibri minion info  -  $(Get-Date)  -  PC $env:COMPUTERNAME  -  user $env:USERNAME" | Out-File $out -Encoding UTF8

Sec "Windows"
try { Put (Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, LastBootUpTime) } catch { Put $_.Exception.Message }

Sec "This PC's network addresses"
try { Put (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike "127.*" } | Select-Object InterfaceAlias, IPAddress, PrefixLength) } catch { Put (ipconfig) }

Sec "Colibri / minion related programs running"
$procs = Get-Process | Where-Object { $_.ProcessName -match "colibri|core|minion|camera|lidar|scan" }
Put ($procs | Select-Object Id, ProcessName, @{n="Path";e={try{$_.Path}catch{""}}}, StartTime | Sort-Object ProcessName)
$byPid = @{}; Get-Process | ForEach-Object { $byPid[$_.Id] = $_.ProcessName }

Sec "Listening ports (with program)"
try { Put (Get-NetTCPConnection -State Listen | Where-Object { $_.LocalAddress -ne "127.0.0.1" -and $_.LocalAddress -ne "::1" } | Select-Object LocalAddress, LocalPort, @{n="Program";e={$byPid[[int]$_.OwningProcess]}} | Sort-Object LocalPort) } catch { Put (netstat -ano | Select-String "LISTENING") }

Sec "Established connections on the local scanner network (not internet)"
try {
  $est = Get-NetTCPConnection -State Established | Where-Object { $_.RemoteAddress -match "^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.)" }
  Put ($est | Select-Object LocalPort, RemoteAddress, RemotePort, @{n="Program";e={$byPid[[int]$_.OwningProcess]}} | Sort-Object Program, RemoteAddress)
  Sec "Connection count per program and local port"
  Put ($est | Group-Object { "{0} port {1}" -f $byPid[[int]$_.OwningProcess], $_.LocalPort } | Select-Object Count, Name | Sort-Object Count -Descending)
} catch { Put (netstat -ano | Select-String "ESTABLISHED") }

Sec "Devices seen on the local network (neighbor table)"
try { Put (Get-NetNeighbor -AddressFamily IPv4 | Where-Object { $_.State -ne "Unreachable" -and $_.IPAddress -notmatch "^(224|239|255)\." -and $_.IPAddress -notlike "*.255" } | Select-Object InterfaceAlias, IPAddress, LinkLayerAddress, State | Sort-Object IPAddress) } catch { Put (arp -a) }

Sec "Colibri Core folders (names and sizes only)"
$roots = @()
foreach ($base in @("C:\Users", "C:\ProgramData", "C:\Program Files", "C:\Program Files (x86)")) {
  try { $roots += Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | ForEach-Object { Get-ChildItem $_.FullName -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "colibri" } } } catch {}
  try { $roots += Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "colibri" } } catch {}
}
$roots = $roots | Sort-Object FullName -Unique
foreach ($r in $roots) {
  Put ("--- " + $r.FullName)
  Put (Get-ChildItem $r.FullName -Recurse -Depth 2 -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer } | Sort-Object LastWriteTime -Descending | Select-Object -First 60 LastWriteTime, Length, FullName)
}

Sec "Newest log files (last 150 lines each)"
$logs = foreach ($r in $roots) { Get-ChildItem $r.FullName -Recurse -Depth 4 -Include *.log, *.txt -ErrorAction SilentlyContinue | Where-Object { $_.FullName -match "log" } }
foreach ($l in ($logs | Sort-Object LastWriteTime -Descending | Select-Object -First 3)) {
  Put ("--- " + $l.FullName + "  (" + $l.LastWriteTime + ")")
  try { Put (Get-Content $l.FullName -Tail 150 -ErrorAction Stop) } catch { Put $_.Exception.Message }
}

Write-Host ""
Write-Host "Done. Saved: $out" -ForegroundColor Green
Write-Host "Send that file to Xavier (or Claude)." -ForegroundColor Green
